<?php
/**
 * Mini-cart
 *
 * Contains the markup for the mini-cart, used by the cart widget.
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/cart/mini-cart.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://docs.woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 5.2.0
 */

defined( 'ABSPATH' ) || exit;

do_action( 'woocommerce_before_mini_cart' ); ?>

<?php if ( isset( WC()->cart ) && ! WC()->cart->is_empty() ) : ?>
	<div class="orderable-sb-container" data-orderable-scroll-id="cart">
		<ul class="orderable-mini-cart <?php echo esc_attr( $args['list_class'] ); ?>">
			<?php
			do_action( 'woocommerce_before_mini_cart_contents' );

			foreach ( WC()->cart->get_cart() as $cart_item_key => $cart_item ) {
				$_product   = apply_filters( 'woocommerce_cart_item_product', $cart_item['data'], $cart_item, $cart_item_key );
				$product_id = apply_filters( 'woocommerce_cart_item_product_id', $cart_item['product_id'], $cart_item, $cart_item_key );

				if ( $_product && $_product->exists() && $cart_item['quantity'] > 0 && apply_filters( 'woocommerce_widget_cart_item_visible', true, $cart_item, $cart_item_key ) ) {
					$product_name        = apply_filters( 'woocommerce_cart_item_name', $_product->get_name(), $cart_item, $cart_item_key );
					$thumbnail           = apply_filters( 'woocommerce_cart_item_thumbnail', $_product->get_image(), $cart_item, $cart_item_key );
					$product_price       = apply_filters( 'woocommerce_cart_item_price', WC()->cart->get_product_price( $_product ), $cart_item, $cart_item_key );
					$product_permalink   = apply_filters( 'woocommerce_cart_item_permalink', $_product->is_visible() ? $_product->get_permalink( $cart_item ) : '', $cart_item, $cart_item_key );
					$formatted_cart_data = wc_get_formatted_cart_item_data( $cart_item, true );
					?>
					<li class="orderable-mini-cart-item <?php echo esc_attr( apply_filters( 'woocommerce_mini_cart_item_class', 'mini_cart_item', $cart_item, $cart_item_key ) ); ?>">
						<?php if ( 'variation' === $_product->get_type() || ! empty( $cart_item['orderable_fields'] ) ) : ?>
							<button
								class="orderable-button orderable-edit-cart-item__button orderable-button--filled"
								data-orderable-trigger="edit-cart-item"
								data-orderable-cart-item-key="<?php echo esc_attr( $cart_item_key ); ?>"
							>
								<?php echo esc_html__( 'Edit', 'orderable' ); ?>
							</button>
						<?php endif; ?>
						<?php
						echo apply_filters( // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
							'woocommerce_cart_item_remove_link',
							sprintf(
								'<a href="%s" class="orderable-mini-cart-item__remove remove_from_cart_button" aria-label="%s" data-product_id="%s" data-cart_item_key="%s" data-product_sku="%s"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><rect x="0" fill="none" width="20" height="20"/><g><path d="M12 4h3c.6 0 1 .4 1 1v1H3V5c0-.6.5-1 1-1h3c.2-1.1 1.3-2 2.5-2s2.3.9 2.5 2zM8 4h3c-.2-.6-.9-1-1.5-1S8.2 3.4 8 4zM4 7h11l-.9 10.1c0 .5-.5.9-1 .9H5.9c-.5 0-.9-.4-1-.9L4 7z"/></g></svg></a>',
								esc_url( wc_get_cart_remove_url( $cart_item_key ) ),
								esc_attr__( 'Remove this item', 'woocommerce' ),
								esc_attr( $product_id ),
								esc_attr( $cart_item_key ),
								esc_attr( $_product->get_sku() )
							),
							$cart_item_key
						);
						?>
						<strong><?php echo wp_kses_post( $product_name ); ?></strong>

						

						<?php if ( ! empty( $formatted_cart_data ) ) { ?>
							<div><?php echo wp_kses_post( nl2br( $formatted_cart_data ) ); ?></div>
						<?php } ?>

						<div class="orderable-quantity-roller">
							<span class="orderable-quantity-roller__roller">
								<button class="orderable-quantity-roller__button orderable-quantity-roller__button--decrease" data-orderable-trigger="decrease-quantity" data-orderable-cart-item-key="<?php echo esc_attr( $cart_item_key ); ?>" data-orderable-product-id="<?php echo esc_attr( $product_id ); ?>" data-orderable-quantity="<?php echo esc_attr( $cart_item['quantity'] ); ?>">-</button>
								<span
									class="orderable-quantity-roller__quantity"
									contenteditable="true"
									inputmode="numeric"
									data-orderable-cart-item-key="<?php echo esc_attr( $cart_item_key ); ?>"
									data-orderable-product-id="<?php echo esc_attr( $product_id ); ?>"
								>
									<?php echo esc_html( $cart_item['quantity'] ); ?>
								</span>
								<button class="orderable-quantity-roller__button orderable-quantity-roller__button--increase" data-orderable-trigger="increase-quantity" data-orderable-cart-item-key="<?php echo esc_attr( $cart_item_key ); ?>" data-orderable-product-id="<?php echo esc_attr( $product_id ); ?>" data-orderable-quantity="<?php echo esc_attr( $cart_item['quantity'] ); ?>">+</button>
							</span>
							<span class="orderable-quantity-roller__price"><?php echo wp_kses_post( $product_price ); ?></span>
						</div>
					</li>
					<?php
				}
			}

			do_action( 'woocommerce_mini_cart_contents' );
			?>
		</ul>
	</div>

	<?php if ( Orderable_Helpers::has_notices() ) { ?>
		<div class="orderable-mini-cart__notices">
			<?php wc_print_notices(); ?>
		</div>
	<?php } ?>

	<?php do_action( 'woocommerce_widget_shopping_cart_before_total' ); ?>

	<p class="orderable-mini-cart__total total">
		<?php
		/**
		 * Hook: woocommerce_widget_shopping_cart_total.
		 *
		 * @hooked woocommerce_widget_shopping_cart_subtotal - 10
		 */
		do_action( 'woocommerce_widget_shopping_cart_total' );
		?>
	</p>

	<?php do_action( 'woocommerce_widget_shopping_cart_before_buttons' ); ?>

	<p class="orderable-mini-cart__buttons buttons"><?php do_action( 'woocommerce_widget_shopping_cart_buttons' ); ?></p>

	<?php do_action( 'woocommerce_widget_shopping_cart_after_buttons' ); ?>

<?php else : ?>

	<p class="orderable-mini-cart__empty-message"><?php esc_html_e( 'No products in the cart.', 'woocommerce' ); ?></p>

<?php endif; ?>

<?php do_action( 'woocommerce_after_mini_cart' ); ?>
