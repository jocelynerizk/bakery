<?php
/**
 * Module: Services order.
 *
 * @package Orderable/Classes
 */

defined( 'ABSPATH' ) || exit;

/**
 * Services order class.
 */
class Orderable_Services_Order {
	/**
	 * Init.
	 */
	public static function run() {
		add_action( 'restrict_manage_posts', array( __CLASS__, 'services_filter' ), 50 );
		add_action( 'pre_get_posts', array( __CLASS__, 'filter_admin_orders' ), 100 );
		add_filter( 'manage_edit-shop_order_columns', array( __CLASS__, 'add_admin_order_columns' ), 10 );
		add_action( 'manage_shop_order_posts_custom_column', array( __CLASS__, 'add_admin_order_columns_content' ), 10, 2 );
		add_filter( 'orderable_get_order_date_time', array( __CLASS__, 'modify_order_date_time_labels' ), 10, 2 );
		add_action( 'woocommerce_before_order_object_save', array( __CLASS__, 'before_save_order' ), 10, 2 );
	}

	/**
	 * Services filter.
	 */
	public static function services_filter() {
		$service = self::get_filtered_service();
		?>
		<select name="orderable_service">
			<option value=""><?php esc_attr_e( 'All services', 'orderable' ); ?></option>
			<option value="delivery" <?php selected( $service, 'delivery' ); ?>><?php esc_attr_e( 'Delivery', 'orderable' ); ?></option>
			<option value="pickup" <?php selected( $service, 'pickup' ); ?>><?php esc_attr_e( 'Pickup', 'orderable' ); ?></option>
		</select>
		<?php
	}

	/**
	 * Get filtered service.
	 *
	 * @return mixed
	 */
	public static function get_filtered_service() {
		// phpcs:ignore WordPress.Security.NonceVerification
		$service = empty( $_GET['orderable_service'] ) ? '' : sanitize_text_field( wp_unslash( $_GET['orderable_service'] ) );

		if ( ! $service ) {
			return '';
		}

		return $service;
	}

	/**
	 * Filter orders.
	 *
	 * @param WP_Query $query
	 */
	public static function filter_admin_orders( $query ) {
		if ( ! Orderable_Orders::is_orders_page() || 'shop_order' !== $query->get( 'post_type' ) ) {
			return;
		}

		$meta_query = (array) $query->get( 'meta_query' );
		$service    = self::get_filtered_service();

		if ( ! empty( $service ) ) {
			$meta_query[] = array(
				'key'   => '_orderable_service_type',
				'value' => $service,
			);
		}

		$query->set( 'meta_query', $meta_query );
	}

	/**
	 * Get service type for an order.
	 *
	 * @param WC_Order $order
	 *
	 * @return bool|string
	 */
	public static function get_service_type( $order ) {
		$shipping_methods = $order->get_shipping_methods();
		$type             = false;

		if ( empty( $shipping_methods ) ) {
			return apply_filters( 'orderable_get_service_type', $type, $order );
		}

		$shipping_method    = array_shift( $shipping_methods );
		$shipping_method_id = $shipping_method->get_method_id();

		$type = Orderable_Services::is_pickup_method( $shipping_method_id ) ? 'pickup' : 'delivery';

		return apply_filters( 'orderable_get_service_type', $type, $order );
	}

	/**
	 * Add columns to admin orders screen.
	 *
	 * @param array $columns
	 *
	 * @return array
	 */
	public static function add_admin_order_columns( $columns ) {
		$columns['orderable_service_type'] = __( 'Service', 'orderable' );

		return $columns;
	}

	/**
	 * Add columns content to admin orders screen.
	 *
	 * @param $column_name
	 * @param $post_id
	 */
	public static function add_admin_order_columns_content( $column_name, $post_id ) {
		if ( 'orderable_service_type' === $column_name ) {
			$order = wc_get_order( $post_id );
			$type  = self::get_service_type( $order );

			if ( empty( $type ) ) {
				echo '&mdash;';

				return;
			}

			$background = 'pickup' === $type ? '#C6C7E1' : '#c5e2df';
			$color      = 'pickup' === $type ? '#5457a0' : '#356964';

			$background = apply_filters( 'orderable_service_type_column_background_color', $background, $column_name, $post_id, $order, $type );
			$color      = apply_filters( 'orderable_service_type_column_text_color', $color, $column_name, $post_id, $order, $type );

			printf( '<mark class="order-status order-status--%s" style="background-color: %s; color: %s;"><span>%s</span></mark>', esc_attr( $type ), esc_attr( $background ), esc_attr( $color ), Orderable_Services::get_service_label( $type ) );
		}
	}

	/**
	 * Modify order date/time labels.
	 *
	 * @param array    $labels
	 * @param WC_Order $order
	 *
	 * @return array
	 */
	public static function modify_order_date_time_labels( $labels, $order ) {
		$type       = Orderable_Services_Order::get_service_type( $order );
		$type_label = Orderable_Services::get_service_label( $type );

		/* translators: 1: service name; 2: date label. E.g.: "Pickup Date", "Delivery Date" */
		$labels['order_date']['label'] = sprintf( _x( '%1$s %2$s', 'Order date', 'orderable' ), $type_label, $labels['order_date']['label'] );
		/* translators: 1: service name; 2: time label. E.g.: "Pickup Time", "Delivery Time" */
		$labels['order_time']['label'] = sprintf( _x( '%1$s %2$s', 'Order time', 'orderable' ), $type_label, $labels['order_time']['label'] );

		return $labels;
	}

	/**
	 * Save order meta.
	 *
	 * @param WC_Abstract_Order $abstract_order
	 * @param WC_Data_Store     $data_store
	 *
	 * @return string
	 */
	public static function before_save_order( $abstract_order, $data_store ) {
		if ( empty( $abstract_order ) ) {
			return;
		}

		$type = Orderable_Services_Order::get_service_type( $abstract_order );

		$abstract_order->update_meta_data( '_orderable_service_type', $type );
	}
}