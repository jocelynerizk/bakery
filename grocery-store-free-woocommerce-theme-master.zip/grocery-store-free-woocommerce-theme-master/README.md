Grocery Store Free Woocommerce Theme 
========================================

<br/>
<h4><a href="https://athemeart.com/demo/grocery-store/" target="_blank">Live Demo 1</a>  |   
<a href="https://athemeart.com/docs/wordpress-woocommerce-theme-docs/" target="_blank">Documentation</a> </h4>
<br/>

<a href="https://athemeart.com/downloads/grocerystore-wordpress-woocommerce-theme/" target="_blank"><img src="https://athemeart.com/wp-content/uploads/edd/2020/09/grocery-store-free-woocommerce-theme.jpg" alt="Wordpress Woocommerce theme"></a>

Here is the new multipurpose <a href="https://athemeart.com/downloads/grocerystore-wordpress-woocommerce-theme/" target="_blank">Wordpress Woocommerce theme</a> named Grocery-Store theme. It's built with the most recent technology and passed the WordPress and WooCommerce standards qualification. Plus, its sorted by advanced features and plenty of options to customize the whole theme.

So, do you need a <a href="https://athemeart.com/downloads/grocery-store-free-woocommerce-theme/" target="_blank">free WooCommerce theme</a>? Or, need a new multipurpose WordPress WooCommerce theme for your online WordPress store? Where you can customize the whole theme like top to bottom. Look no further! just watch the Grocery-Store theme demos.

First of all, the theme is dedicately create for any kind of or multipurpose online WordPress store purposes. For instance, you can use the theme for fashion, sport, technology, furniture, beauty, health, or any WordPress store. Besides, this store theme will display more attractively on your device or screen because of its responsiveness design.

Its product presentation options are so well-furnishes that you'll mesmerize in the difference of other online store themes. Also, it's run so accurately with the most popular and common page builders. Like WPBakery Page Builder, Elementor, Brizy, Beaver Builder, Visual Composer, SiteOrigin, Divi, and many more. And most importantly, you don’t have to be an expert in coding or hire a skilled coder, because that’s a theme ready to use.

Please check our demos or videos to know more about the <strong>WordPress store theme</strong>. We hope that the WordPress Grocery-Store theme is the only helpful theme you always wanted.

Installation 
========================================
1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload Theme and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.



Changelog
========================================
<pre>
= 1.0.1  =
* .pot file updated

= 1.0.0  =

* Initial release
</pre>


Credits 
========================================
<pre>
Bootstrap:
Author: Twitter
Source: http://getbootstrap.com
License: Licensed under the MIT license

Underscores:
Author: 2012-2015 Automattic
Source: http://underscores.me
License: GPLv2 or later

Customizer:
Author: https://github.com/justintadlock
Source: https://github.com/justintadlock/trt-customizer-pro
License: GNU GPL

Owl Carousel 2:
Author: David Deutsch
Source: https://github.com/OwlCarousel2/OwlCarousel2
License: [MIT License.]

Sticky Plugin :
Author:  Anthony Garand    
Source: https://github.com/garand/sticky
License: MIT License

Tgmpluginactivation:
Source: http://tgmpluginactivation.com/
License: GPL-2.0 or later license.

AOS:
Source: https://github.com/michalsnik/aos/
License: MIT License.

icofont:
Source: https://icofont.com/license
License: MIT License.

jquery.customSelect:
Author:  Adam Coulombe    
Source: http://adam.co/lab/jquery/customselect/
License: GPL2

RD Navbar :
Author:  OXAYAZA    
Source: https://github.com/ZemezPlugins/rd-navbar
License: GPLv2 or later

== Image Used ==

https://pxhere.com/en/photo/819863
https://pxhere.com/en/photo/874477
https://pxhere.com/en/photo/520086
https://pxhere.com/en/photo/1048649
https://pxhere.com/en/photo/1222205
https://pxhere.com/en/photo/783956
License:  CC0 Public Domain 

Name : screenshot.png logo
License:  Self created by athemeart.com 
</pre>


Copyright
========================================
<a href="https://bddesignzone.com/grocery-store-wordpress-woocommerce-theme/" target="_blank">Grocery Store</a> WordPress Theme, Copyright (C) 2020 aThemeArt.com
Grocery Store is distributed under the terms of the MIT License 